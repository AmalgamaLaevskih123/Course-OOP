public class Primes {
    public static void main(String[] args) {
        for (int i = 2; i <= 100; i++) //метод выводит все простые числа
            if (isPrime(i)) 
                System.out.println(i);
    }
    public static boolean isPrime(int n){  // метод в котором проверяется простое
        boolean is_Prime = true;           // число или нет
        for (int i = 2; i < Math.sqrt(n); i++)
            if (n % i == 0) is_Prime = false;
        return is_Prime;
    }
}
